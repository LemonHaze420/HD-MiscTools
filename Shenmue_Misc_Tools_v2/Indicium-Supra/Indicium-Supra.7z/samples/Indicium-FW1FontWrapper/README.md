# Indicium-FW1FontWrapper
DirectX 11 example.

## About
Demonstrates how to render text in foreign processes by using [FW1FontWrapper](https://github.com/gamelaster/FW1FontWrapper) library:

![](https://lh3.googleusercontent.com/-DCgMGmAbCPg/Wu4Pa1hViaI/AAAAAAAABLQ/MO7bOgF3KDQLz24iWUjqP_-knr961sFMQCHMYCw/s0/RoadRedemption_2018-05-05_22-09-12.png)
